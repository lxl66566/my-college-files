while print:
    first=float(input("***************************************\r\n*1 个人信息二维码   2 四叶草的动态绘制*\r\n*3 自动关机小程序   4 师生举行募捐活动*\r\n***************************************\r\n请输入您的选择(输入0退出):"))
    if first==1:
        import qrcode
        grxx=input("请输入您的信息（姓名 学号 专业）：")
        img = qrcode.make(grxx)
        img.save("个人信息.jpg")
    elif first==2:
        import turtle
        import time
        turtle.setup(650.,350,200,200)
        turtle.pendown()
        turtle.pensize(10)
        turtle.pencolor('green')
        
        #四叶草
        def draw_clover(radius,rotate):               #参数radius控制叶于的大小, rotate控制叶子的旋转
            for i in range(4):
                direction = i*90
                turtle.seth(60+direction+rotate)      #控制叶于根部的角度为60度
                # turtle.fd(2*radius*pow(2,1/2))      #控制叶子根部的角度为90度
                turtle.fd(4*radius)
                for j in range(2):
                    turtle.seth(90+direction+rotate)
                    turtle.circle(radius,180)
                turtle.seth(-60+direction+rotate)
                turtle.fd(4*radius)
            turtle.seth(-90)
            turtle.fd(6*radius)
                      
        draw_clover(30,45)
        time.sleep(5)
        print("绘制完成！")
    elif first==3:
        shutdown_time=str(input("您希望多少秒之后关机："))
        yn=input("是否关机Y/N：")
        if yn=='N':
            print("取消关机成功")
        elif yn=='Y':
            import os
            os.system("shutdown -s -t "+shutdown_time)
        else:
            print("请重新选择")
    elif first==4:
        people=1
        total=0
        while people<=4:
            money=int(input("请输入您的捐款："))
            people=people+1
            total=total+money
            if people>=5:
                break
        average=total/4
        print("捐款人数为四人，平均金额为%.2f"%(average))
    else:
        print("您输入有误，请重新输入，谢谢！")
    print("***************************************")
        
    
        

    
        

        

        
