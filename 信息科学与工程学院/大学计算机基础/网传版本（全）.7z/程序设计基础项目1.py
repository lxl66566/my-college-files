while print:
    first=str(input("请输入您的选择1、2或其它："))
    if first=="1":
        money=int(input("请输入红包金额：")) 
        num1=int(input("请输入红包个数:"))
        total=money*num1
        print("红包总金额为：%.1f"%total)
    elif first=="2":
        import random
        num2=random.randint(1,6)
        guess=int(input("请输入您的猜测："))
        if guess==num2:
            print("您猜对了，数字是%d"%num2)
        elif guess>num2:
            print("您猜大了，数字是%d"%num2)
        else:
            print("您猜小了，数字是%d"%num2)
    else:
        print(input("您的输入有误！！！"))
